<?php
// Heading
$_['heading_title']       = 'Layouts';

// Text
$_['text_success']        = 'Layout modificado com sucesso!';
$_['text_list']           = 'Listando layouts';
$_['text_add']            = 'Novo layout';
$_['text_edit']           = 'Editando layout';
$_['text_remove']         = 'Remover';
$_['text_route']          = 'Rotas e lojas';
$_['text_module']         = 'Organização dos módulos';
$_['text_default']        = 'Padrão';
$_['text_content_top']    = 'Topo do conteúdo';
$_['text_content_bottom'] = 'Rodapé do conteúdo';
$_['text_column_left']    = 'Coluna da esquerda';
$_['text_column_right']   = 'Coluna da direita';

// Column
$_['column_name']         = 'Layout';
$_['column_action']       = 'Ação';

// Entry
$_['entry_name']          = 'Layout';
$_['entry_store']         = 'Loja';
$_['entry_route']         = 'Rota';
$_['entry_module']        = 'Módulo';

// Error
$_['error_permission']    = 'Atenção: Você não tem permissão para modificar os layouts.';
$_['error_name']          = 'O layout deve ter entre 3 e 64 caracteres.';
$_['error_module']        = 'Módulo obrigatório.';
$_['error_default']       = 'Atenção: Este layout não pode ser excluído, pois ele está atualmente definido como o layout padrão da loja.';
$_['error_store']         = 'Atenção: Este layout não pode ser excluído, pois ele está ligado à %s lojas.';
$_['error_product']       = 'Atenção: Este layout não pode ser excluído, pois ele está ligado à %s produtos.';
$_['error_category']      = 'Atenção: Este layout não pode ser excluído, pois ele está ligado à %s departamentos.';
$_['error_manufacturer']  = 'Atenção: Este layout não pode ser excluído, pois ele está ligado à %s marcas.';
$_['error_information']   = 'Atenção: Este layout não pode ser excluído, pois ele está ligado à %s páginas de informações.';
